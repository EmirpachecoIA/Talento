
export interface Term {
  term: string;
  definition: string;
}

export interface QuizQuestion {
  term: string;
  options: string[];
  correctAnswer: string;
}
