
import React from 'react';

interface ScoreScreenProps {
    score: number;
    totalQuestions: number;
    onRestart: () => void;
}

export const ScoreScreen: React.FC<ScoreScreenProps> = ({ score, totalQuestions, onRestart }) => {
    const percentage = Math.round((score / totalQuestions) * 100);
    let message = '';
    if (percentage > 80) {
        message = '¡Excelente trabajo! Eres un experto en Talento.';
    } else if (percentage > 50) {
        message = '¡Buen intento! Sigue practicando para dominar los conceptos.';
    } else {
        message = '¡Sigue estudiando! El conocimiento es poder.';
    }

    return (
        <div className="text-center bg-slate-800/50 backdrop-blur-sm p-8 rounded-xl shadow-2xl border border-blue-800 animate-fade-in">
            <h2 className="text-3xl font-bold mb-4 text-blue-300">Juego Terminado</h2>
            <p className="text-lg text-white mb-2">Tu puntuación final es:</p>
            <p className="text-6xl font-bold text-blue-400 my-4">
                {score} <span className="text-4xl text-blue-200">/ {totalQuestions}</span>
            </p>
            <p className="text-xl text-blue-200 font-semibold mb-8">{message}</p>
            <button
                onClick={onRestart}
                className="bg-blue-600 hover:bg-blue-500 text-white font-bold py-3 px-8 rounded-lg text-lg transition-all duration-300 ease-in-out transform hover:scale-105 shadow-lg hover:shadow-blue-500/50 focus:outline-none focus:ring-4 focus:ring-blue-400 focus:ring-opacity-50"
            >
                Jugar de Nuevo
            </button>
        </div>
    );
};
