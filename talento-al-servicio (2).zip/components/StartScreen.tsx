
import React from 'react';

interface StartScreenProps {
    onStart: () => void;
}

export const StartScreen: React.FC<StartScreenProps> = ({ onStart }) => {
    return (
        <div className="text-center bg-slate-800/50 backdrop-blur-sm p-8 rounded-xl shadow-2xl border border-blue-800 animate-fade-in">
            <h2 className="text-2xl font-semibold mb-4 text-white">¡Bienvenido al Desafío!</h2>
            <p className="text-blue-200 mb-8 max-w-md mx-auto">
                Pon a prueba tus conocimientos sobre los términos clave de RR.HH. Se te presentarán 10 términos. ¡Elige la definición correcta para cada uno y consigue la puntuación más alta!
            </p>
            <button
                onClick={onStart}
                className="bg-blue-600 hover:bg-blue-500 text-white font-bold py-3 px-8 rounded-lg text-lg transition-all duration-300 ease-in-out transform hover:scale-105 shadow-lg hover:shadow-blue-500/50 focus:outline-none focus:ring-4 focus:ring-blue-400 focus:ring-opacity-50"
            >
                Comenzar Juego
            </button>
        </div>
    );
};
