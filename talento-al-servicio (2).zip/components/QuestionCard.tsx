
import React, { useState, useEffect } from 'react';
import type { QuizQuestion } from '../types';
import { ProgressBar } from './ProgressBar';
import { CheckIcon } from './icons/CheckIcon';
import { XIcon } from './icons/XIcon';

interface QuestionCardProps {
    question: QuizQuestion;
    onAnswer: (isCorrect: boolean) => void;
    questionNumber: number;
    totalQuestions: number;
}

export const QuestionCard: React.FC<QuestionCardProps> = ({ question, onAnswer, questionNumber, totalQuestions }) => {
    const [selectedAnswer, setSelectedAnswer] = useState<string | null>(null);
    const [isAnswered, setIsAnswered] = useState<boolean>(false);

    useEffect(() => {
        setSelectedAnswer(null);
        setIsAnswered(false);
    }, [question]);

    const handleOptionClick = (option: string) => {
        if (isAnswered) return;
        
        const isCorrect = option === question.correctAnswer;
        setSelectedAnswer(option);
        setIsAnswered(true);
        onAnswer(isCorrect);
    };

    const getButtonClass = (option: string) => {
        if (!isAnswered) {
            return 'bg-slate-700 hover:bg-blue-800 border-slate-600';
        }
        if (option === question.correctAnswer) {
            return 'bg-green-500/80 border-green-400 scale-105';
        }
        if (option === selectedAnswer) {
            return 'bg-red-500/80 border-red-400';
        }
        return 'bg-slate-800 border-slate-700 opacity-50';
    };

    return (
        <div className="bg-slate-800/50 backdrop-blur-sm p-6 md:p-8 rounded-xl shadow-2xl border border-blue-800 animate-fade-in-up">
            <ProgressBar current={questionNumber} total={totalQuestions} />
            <div className="mt-4 mb-6">
                <p className="text-sm text-blue-300 font-medium">Pregunta {questionNumber} de {totalQuestions}</p>
                <h2 className="text-2xl md:text-3xl font-bold mt-1">
                    ¿Cuál es la definición de "{question.term}"?
                </h2>
            </div>
            <div className="space-y-3">
                {question.options.map((option, index) => (
                    <button
                        key={index}
                        onClick={() => handleOptionClick(option)}
                        disabled={isAnswered}
                        className={`w-full text-left p-4 rounded-lg border-2 text-white transition-all duration-300 ease-in-out flex justify-between items-center ${getButtonClass(option)} ${!isAnswered ? 'cursor-pointer' : 'cursor-default'}`}
                    >
                        <span className="flex-1 pr-4">{option}</span>
                        {isAnswered && option === question.correctAnswer && <CheckIcon className="w-6 h-6 text-white" />}
                        {isAnswered && option === selectedAnswer && option !== question.correctAnswer && <XIcon className="w-6 h-6 text-white" />}
                    </button>
                ))}
            </div>
        </div>
    );
};
