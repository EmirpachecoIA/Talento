
import React, { useState, useCallback, useEffect } from 'react';
import { StartScreen } from './components/StartScreen';
import { QuestionCard } from './components/QuestionCard';
import { ScoreScreen } from './components/ScoreScreen';
import { generateQuizData } from './data/terms';
import type { QuizQuestion } from './types';

type GameState = 'start' | 'playing' | 'finished';
const TOTAL_QUESTIONS = 10;

const App: React.FC = () => {
    const [gameState, setGameState] = useState<GameState>('start');
    const [questions, setQuestions] = useState<QuizQuestion[]>([]);
    const [currentQuestionIndex, setCurrentQuestionIndex] = useState<number>(0);
    const [score, setScore] = useState<number>(0);

    const startGame = useCallback(() => {
        setScore(0);
        setCurrentQuestionIndex(0);
        setQuestions(generateQuizData(TOTAL_QUESTIONS));
        setGameState('playing');
    }, []);

    const restartGame = useCallback(() => {
        setGameState('start');
    }, []);

    const handleAnswer = useCallback((isCorrect: boolean) => {
        if (isCorrect) {
            setScore(prevScore => prevScore + 1);
        }

        const nextQuestion = currentQuestionIndex + 1;
        setTimeout(() => {
            if (nextQuestion < questions.length) {
                setCurrentQuestionIndex(nextQuestion);
            } else {
                setGameState('finished');
            }
        }, 1200); // Wait a moment before showing the next question
    }, [currentQuestionIndex, questions.length]);

    return (
        <main className="min-h-screen bg-gradient-to-br from-slate-900 to-blue-900 text-white flex flex-col items-center justify-center p-4 font-sans">
            <div className="w-full max-w-2xl mx-auto">
                <h1 className="text-4xl md:text-5xl font-bold text-center mb-2 text-blue-300 tracking-wide">
                    Talento al Servicio
                </h1>
                <p className="text-center text-blue-200 opacity-80 mb-8">Desafío de Conocimiento de RR.HH.</p>

                {gameState === 'start' && <StartScreen onStart={startGame} />}
                
                {gameState === 'playing' && questions.length > 0 && (
                    <QuestionCard
                        question={questions[currentQuestionIndex]}
                        onAnswer={handleAnswer}
                        questionNumber={currentQuestionIndex + 1}
                        totalQuestions={questions.length}
                    />
                )}

                {gameState === 'finished' && (
                    <ScoreScreen
                        score={score}
                        totalQuestions={questions.length}
                        onRestart={restartGame}
                    />
                )}
            </div>
        </main>
    );
};

export default App;
