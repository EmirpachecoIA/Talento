import type { Term, QuizQuestion } from '../types';

const shuffleArray = <T,>(array: T[]): T[] => {
  return [...array].sort(() => Math.random() - 0.5);
};

const ALL_TERMS: Term[] = [
    { term: 'Digital Transformation', definition: 'Es la integración de tecnología en todos los procesos de talento para hacer la atracción más amplia, la selección más objetiva y la contratación más ágil.' },
    { term: 'Artificial Intelligence', definition: 'Es el uso de algoritmos para automatizar y potenciar decisiones, como atraer talento pasivo, pre-filtrar CVs y predecir el éxito de un candidato.' },
    { term: 'HR Automation', definition: 'Es programar sistemas para que realicen tareas operativas como enviar correos de seguimiento, agendar entrevistas y generar pre-contratos.' },
    { term: 'People Analytics', definition: 'Es el análisis de datos para fundamentar decisiones de talento, optimizando la atracción e identificando qué fuentes traen los mejores candidatos.' },
    { term: 'HRIS', definition: 'Es la plataforma central que gestiona los datos de los empleados, y su integración es vital para transferir la información del nuevo empleado sin errores.' },
    { term: 'ATS', definition: 'Es el software principal para gestionar el reclutamiento, centralizando perfiles y gestionando cada etapa de la selección.' },
    { term: 'Big Data', definition: 'Es el análisis de grandes volúmenes de datos del mercado laboral para entender tendencias salariales y de demanda de perfiles.' },
    { term: 'Virtual Reality (VR)', definition: 'Son entornos simulados inmersivos que se pueden usar en selección para evaluar habilidades prácticas en un entorno seguro y realista.' },
    { term: 'Augmented Reality (AR)', definition: 'Es superponer información digital en el mundo real, útil en ferias laborales o para guiar en pruebas técnicas.' },
    { term: 'HR Chatbot', definition: 'Es un asistente virtual para interactuar con candidatos, disponible 24/7 para responder dudas o realizar pre-entrevistas.' },
    { term: 'Gamification', definition: 'Es usar mecánicas de juego para motivar y evaluar habilidades de forma más dinámica y atractiva en la selección.' },
    { term: 'Digital Onboarding', definition: 'Es el proceso de bienvenida online para nuevos empleados, asegurando que la experiencia de selección continúe y reduciendo la rotación temprana.' },
    { term: 'Talent Management', definition: 'Es la estrategia integral para gestionar el ciclo de vida del empleado, desde la atracción hasta el desarrollo y fidelización.' },
    { term: 'Candidate Experience', definition: 'Es la percepción del postulante sobre nuestro proceso; una gran experiencia convierte a los candidatos en promotores de la marca.' },
    { term: 'Employer Branding', definition: 'Es la reputación de la empresa como un gran lugar para trabajar, siendo cada interacción una oportunidad para construirla o destruirla.' },
    { term: 'EVP', definition: 'Es el conjunto de beneficios y recompensas que ofrece la empresa y que debe ser comunicado de forma clara y atractiva.' },
    { term: 'DEI', definition: 'Es el compromiso de crear un entorno justo y representativo, diseñando procesos de atracción y selección libres de sesgos.' },
    { term: 'Organizational Culture', definition: 'Es la "personalidad" de la empresa; en la selección se evalúa el "ajuste cultural" para asegurar que el candidato prospere.' },
    { term: 'Empathic Leadership', definition: 'Es un estilo de liderazgo que conecta con las personas, mostrando empatía y escucha activa durante las entrevistas.' },
    { term: 'Hybrid Work', definition: 'Modelo que combina días de trabajo en la oficina con días en remoto, requiriendo evaluación de autonomía y autogestión.' },
    { term: 'Workplace Wellness', definition: 'Es el cuidado de la salud integral del empleado, y comunicar este compromiso es una poderosa herramienta de atracción.' },
    { term: 'Upskilling', definition: 'Es formar a un empleado en habilidades más avanzadas para que sea mejor en su rol actual, un argumento de atracción.' },
    { term: 'Reskilling', definition: 'Es enseñar a un empleado habilidades completamente nuevas para que pueda moverse a un rol diferente, fomentando la movilidad interna.' },
    { term: 'Soft Skills', definition: 'Son competencias interpersonales como la comunicación o el trabajo en equipo, tan importantes como las técnicas.' },
    { term: 'Resilience', definition: 'Es la capacidad de recuperarse de la adversidad, una cualidad vital en un mundo cambiante que se evalúa en la selección.' },
];

export const generateQuizData = (questionCount: number = 10): QuizQuestion[] => {
    const shuffledTerms = shuffleArray(ALL_TERMS);
    const selectedTerms = shuffledTerms.slice(0, questionCount);

    return selectedTerms.map((correctTerm) => {
        const otherTerms = shuffledTerms.filter(term => term.term !== correctTerm.term);
        const incorrectDefinitions = shuffleArray(otherTerms).slice(0, 3).map(term => term.definition);
        
        const options = shuffleArray([
            correctTerm.definition,
            ...incorrectDefinitions,
        ]);

        return {
            term: correctTerm.term,
            options: options,
            correctAnswer: correctTerm.definition,
        };
    });
};